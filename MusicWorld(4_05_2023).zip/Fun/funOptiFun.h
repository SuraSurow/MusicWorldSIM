//
// Created by surow on 20/03/2023.
//

#ifndef LAB_FUNOPTIFUN_H
#define LAB_FUNOPTIFUN_H

void get_size( size_t *size);
int index(size_t* ptrNum);
void pressEnter();
int index(int * ptrNum);
int index(size_t * ptrNum,size_t maxVal);
//int joinArray(const int arr[], int size, int &result);
//void joinArray(const size_t arr[], int size, size_t &result);


#endif //LAB_FUNOPTIFUN_H
