//
// Created by surow on 20/03/2023.
//
#ifndef LAB_FUNRANDDATA_H
#define LAB_FUNRANDDATA_H

string randName();
string randSurname();
string randAlbumName();
string randTypeMusic();
string randNameMusic();
size_t randSize_t (int min, int max);
string randDistCompany();
string randNickName();
string randExertiseArea();


#endif //LAB_FUNRANDDATA_H
