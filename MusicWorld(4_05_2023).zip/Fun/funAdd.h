//
// Created by surow on 20/03/2023.`
//
#ifndef LAB_FUNADD_H
#define LAB_FUNADD_H

int add ( Album **& _album , const size_t * size , const size_t *size_new);
int add ( Music **& _musicDisc , const size_t * size , const size_t *size_new);
int add ( Musician *& _creator , const size_t * size , const size_t * size_new);
int add ( Producent **& _producent , const size_t *size , const size_t * size_new);
#endif //LAB_FUNADD_H
