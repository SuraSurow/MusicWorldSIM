//
// Created by surow on 16/05/2023.
//

#ifndef LAB_FUNLOAD_H
#define LAB_FUNLOAD_H

void load( Producent **& prod , size_t & size);
void load( Musician *& prod , size_t & size);
void load( Album **& prod , size_t & size);
void load( Music **& music , size_t & size);

#endif //LAB_FUNLOAD_H
