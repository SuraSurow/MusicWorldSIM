//
// Created by surow on 20/03/2023.
//
#ifndef LAB_FUNRANDDATA_H
#define LAB_FUNRANDDATA_H

string randStringData(string _path , string fileName);
string randSurname();
string randAlbumName();
string randTypeMusic();
string randNameMusic();
size_t randSize_t (int min, int max);
string randDistCompany();
string randNickName();
string randExertiseArea();


#endif //LAB_FUNRANDDATA_H
