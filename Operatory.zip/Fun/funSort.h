//
// Created by surow on 21/03/2023.
//

#ifndef LAB_FUNSORT_H
#define LAB_FUNSORT_H

#include "../head/headHeadFile.h"



void sort ( Musician *_creator , const size_t *size );
void sort ( Album ** _album , const size_t *size);
void sort ( Music ** _musicDisc , const size_t *size);
void sort ( Producent ** _prod , const size_t *size);


#endif //LAB_FUNSORT_H
