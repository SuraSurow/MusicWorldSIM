//
// Created by surow on 07/05/2023.
//

#ifndef LAB_PATH_H
#define LAB_PATH_H
#include <filesystem>
#include <string>
std::string path(const std::string& _restTracks);
#endif //LAB_PATH_H
