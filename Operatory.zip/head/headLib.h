//
// Created by surow on 15/05/2023.
//

#ifndef LAB_HEADLIB_H
#define LAB_HEADLIB_H
#include <iostream>
#include <sstream>
#include <fstream>
#include <ostream>
#include <fstream>

#include <string>
#include <cstdlib>
#include <locale>
#include <ctime>
#include <random>
#include <type_traits>
#include <chrono>
#include <algorithm>

#include <filesystem>
#endif //LAB_HEADLIB_H
