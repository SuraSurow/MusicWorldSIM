//
// Created by surow on 20/03/2023.
//

#ifndef LAB_OPTIFUN_H
#define LAB_OPTIFUN_H

void get_size( size_t *size);
int index(size_t* ptrNum);
void pressEnter();
int index(int * ptrNum);
int index(size_t * ptrNum,size_t maxVal);

#endif //LAB_OPTIFUN_H
