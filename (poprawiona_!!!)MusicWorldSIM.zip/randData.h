//
// Created by surow on 20/03/2023.
//
#ifndef LAB_RANDDATA_H
#define LAB_RANDDATA_H

string randName();
string randSurname();
string randAlbumName();
string randTypeMusic();
string randNameMusic();
size_t randSize_t (int min, int max);


#endif //LAB_RANDDATA_H
