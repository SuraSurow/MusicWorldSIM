w headerze  headFile.h w postaci komentarzy jest pokazany caly uklad
funkcji