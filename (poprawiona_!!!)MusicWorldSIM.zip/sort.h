//
// Created by surow on 21/03/2023.
//

#ifndef LAB_SORT_H
#define LAB_SORT_H

#include "headFile.h"



void sort (creator *_creator , size_t *size );
void sort (album ** _album ,size_t *size);
void sort (musicDisc ** _musicDisc ,size_t *size);


#endif //LAB_SORT_H
