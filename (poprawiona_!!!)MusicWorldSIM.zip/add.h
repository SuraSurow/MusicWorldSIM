//
// Created by surow on 20/03/2023.
//
#ifndef LAB_ADD_H
#define LAB_ADD_H

int add (album **& _album , size_t * size ,size_t *size_new);
int add (musicDisc **& _musicDisc , size_t * size ,size_t *size_new);
int add (creator *& _creator , size_t * size , size_t * size_new);

#endif //LAB_ADD_H
