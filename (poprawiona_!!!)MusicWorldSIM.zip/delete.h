//
// Created by surow on 20/03/2023.
//
#ifndef LAB_DELETE_H
#define LAB_DELETE_H

int del ( creator *& _creatorS , size_t *size , size_t *size_new );
int del( album **& _albumS , size_t* size,size_t * size_new );
int del( musicDisc **& _musicDiscES , size_t * size , size_t * size_new);

#endif //LAB_DELETE_H
